<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_message`;");
E_C("CREATE TABLE `zyads_message` (
  `msgid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `msgtype` tinyint(1) NOT NULL DEFAULT '0',
  `senduser` varchar(50) NOT NULL,
  `touser` varchar(50) DEFAULT '0',
  `parentid` mediumint(8) NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL,
  `msgtext` mediumtext NOT NULL,
  `isview` tinyint(1) NOT NULL DEFAULT '0',
  `isadmin` tinyint(1) NOT NULL DEFAULT '1',
  `alone` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` datetime NOT NULL,
  PRIMARY KEY (`msgid`),
  KEY `isadmin` (`isadmin`),
  KEY `senduser` (`senduser`),
  KEY `touser` (`touser`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_message` values('1','0','admin','','0','fffff','ff','1','0','1','2013-12-05 23:54:15');");

require("../../inc/footer.php");
?>