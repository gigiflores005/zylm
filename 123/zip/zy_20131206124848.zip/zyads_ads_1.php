<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_ads`;");
E_C("CREATE TABLE `zyads_ads` (
  `adsid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `planid` mediumint(8) NOT NULL DEFAULT '0',
  `uid` mediumint(9) NOT NULL DEFAULT '0',
  `adinfo` varchar(100) DEFAULT NULL,
  `adstype` varchar(10) NOT NULL,
  `adstypeid` mediumint(8) NOT NULL,
  `imageurl` varchar(255) DEFAULT NULL,
  `imageurl1` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `url` text NOT NULL,
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  `headline` varchar(40) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  `dispurl` varchar(255) DEFAULT NULL,
  `htmlcode` mediumtext,
  `htmltype` char(2) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `denyinfo` varchar(255) DEFAULT NULL,
  `priority` tinyint(3) NOT NULL DEFAULT '1',
  `mark` tinyint(1) NOT NULL DEFAULT '0',
  `zlink` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`adsid`),
  KEY `planid` (`planid`),
  KEY `status` (`status`),
  KEY `width` (`width`),
  KEY `height` (`height`),
  KEY `adstypeid` (`adstypeid`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_ads` values('10','18','1023','','','9','',NULL,'','http://105437.x7shop.com','0','0','','','','',NULL,'2013-12-06 18:21:42','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('11','19','1023','','','9','',NULL,'','http://qq2008.duapp.com','0','0','','','','',NULL,'2013-12-06 18:24:17','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('12','20','1023','','','9','',NULL,'','http://qqshipin.duapp.com','0','0','','','','',NULL,'2013-12-06 18:28:53','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('13','21','1023','','','11','/a/2013-12-06/138632696840566406.jpg',NULL,'','http://www.55tools.com/getsoftcode.php?n=17&u=lmycgs','320','250','','','','',NULL,'2013-12-06 18:49:28','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('14','22','1023','','','7','/a/2013-12-06/138632792669758301.jpg',NULL,'','http://c.sfilm.com/down.php?uid=10313','950','90','','','','',NULL,'2013-12-06 19:05:25','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('15','22','1023','','','7','/a/2013-12-06/138632799049929199.jpg',NULL,'','http://c.sfilm.com/down.php?uid=10313','760','90','','','','',NULL,'2013-12-06 19:06:30','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('9','17','1023','','','16','/a/2013-12-06/138632907655222168.gif',NULL,'','http://www.ak345.com/','468','60','','','','',NULL,'2013-12-06 16:57:15','3',NULL,'1','0','1');");
E_D("replace into `zyads_ads` values('16','22','1023','','','7','/a/2013-12-06/138632809265373535.gif',NULL,'','http://c.sfilm.com/down.php?uid=10313','468','60','','','','',NULL,'2013-12-06 19:08:12','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('17','22','1023','','','7','/a/2013-12-06/138632819277788086.gif',NULL,'','http://c.sfilm.com/down.php?uid=10313','468','60','','','','',NULL,'2013-12-06 19:09:52','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('18','22','1023','','','11','/a/2013-12-06/138632825184528809.gif',NULL,'','http://c.sfilm.com/down.php?uid=10313','300','250','','','','',NULL,'2013-12-06 19:10:51','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('19','23','1023','','','7','/a/2013-12-06/138632881473332520.gif',NULL,'','http://jifendownload.2345.cn/jifen_2345/sohuva_k2208867_208027709.exe','960','60','','','','',NULL,'2013-12-06 19:20:14','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('20','23','1023','','','7','/a/2013-12-06/138632884443530273.gif',NULL,'','http://jifendownload.2345.cn/jifen_2345/sohuva_k2208867_208027709.exe','960','90','','','','',NULL,'2013-12-06 19:20:44','3',NULL,'1','0','0');");
E_D("replace into `zyads_ads` values('21','23','1023','','','11','/a/2013-12-06/138632890082236329.jpg',NULL,'','http://jifendownload.2345.cn/jifen_2345/sohuva_k2208867_208027709.exe','300','250','','','','',NULL,'2013-12-06 19:21:40','3',NULL,'1','0','0');");

require("../../inc/footer.php");
?>