<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip11`;");
E_C("CREATE TABLE `zyads_adsip11` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','455800776','1373474134','1');");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','1901531287','1373474540','2');");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','1959825151','1373503666','3');");
E_D("replace into `zyads_adsip11` values('1002','1004','7','11','15','4','7','1959825151','1373503685','4');");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','2061914241','1373505978','5');");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','3728367976','1373518827','6');");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','2059537767','1373522960','7');");
E_D("replace into `zyads_adsip11` values('1002','1004','6','14','16','4','15','976023300','1373533219','8');");

require("../../inc/footer.php");
?>