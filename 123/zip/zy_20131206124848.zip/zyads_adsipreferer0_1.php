<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipreferer0`;");
E_C("CREATE TABLE `zyads_adsipreferer0` (
  `referer` varchar(1000) DEFAULT NULL,
  `refererid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`refererid`),
  KEY `referer` (`referer`(500))
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipreferer0` values('','1');");
E_D("replace into `zyads_adsipreferer0` values('http://www.liyuanzhao.com/video/list-4.html','2');");
E_D("replace into `zyads_adsipreferer0` values('http://bbs.admin5.com/thread-12188752-1-1.html','3');");
E_D("replace into `zyads_adsipreferer0` values('http://www.admin5.net/thread-8445006-1-1.html','4');");

require("../../inc/footer.php");
?>