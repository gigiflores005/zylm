<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_onlinepay`;");
E_C("CREATE TABLE `zyads_onlinepay` (
  `onlineid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `imoney` double(10,2) NOT NULL DEFAULT '0.00',
  `paytype` char(10) NOT NULL,
  `addtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `orderid` varchar(50) NOT NULL,
  `adminuser` varchar(50) NOT NULL,
  `payinfo` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`onlineid`),
  KEY `orderid` (`orderid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_onlinepay` values('1','guanggaozhu','2000.00','','2013-06-02 12:21:44','','admin','���Թ����','3');");
E_D("replace into `zyads_onlinepay` values('2','zjzz110','888888.00','','2013-07-03 13:07:50','','admin','888/8','3');");
E_D("replace into `zyads_onlinepay` values('3','sdfsdf2342','100.00','','2013-07-26 06:39:01','','admin','1','3');");
E_D("replace into `zyads_onlinepay` values('4','wangzhanzhu','7.00','','2013-12-06 00:20:14','','admin','0','4');");
E_D("replace into `zyads_onlinepay` values('5','lmycgs','1.00','','2013-12-06 00:20:31','','admin','1','3');");
E_D("replace into `zyads_onlinepay` values('6','lmycgs1','100000.00','','2013-12-06 16:53:41','','admin','��','3');");

require("../../inc/footer.php");
?>