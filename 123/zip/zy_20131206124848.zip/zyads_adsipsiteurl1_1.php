<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipsiteurl1`;");
E_C("CREATE TABLE `zyads_adsipsiteurl1` (
  `siteurl` varchar(1000) DEFAULT NULL,
  `siteurlid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`siteurlid`),
  KEY `siteurl` (`siteurl`(500))
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipsiteurl1` values('','1');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.liyuanzhao.com/','2');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.baoxiaotuan.com/video/show-4261.html','3');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.baoxiaotuan.com/','4');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.baoxiaotuan.com/video/show-4553.html','5');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.baoxiaotuan.com/video/show-3509.html','6');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.baoxiaotuan.com/video/show-4256.html','7');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.baoxiaotuan.com/video/show-4382.html','8');");
E_D("replace into `zyads_adsipsiteurl1` values('http://www.ak345.com/888/index.html','9');");
E_D("replace into `zyads_adsipsiteurl1` values('http://ak345.com/888/index.html','10');");

require("../../inc/footer.php");
?>