<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip23`;");
E_C("CREATE TABLE `zyads_adsip23` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','1857285437','1374553106','1');");
E_D("replace into `zyads_adsip23` values('1002','1004','1','11','14','4','7','1857285437','1374553151','2');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','976816932','1374560499','3');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','1007894711','1374564639','4');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','2072172264','1374568940','5');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','244933084','1374569957','6');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','2093864798','1374570734','7');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','3719538818','1374575637','8');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','2047262604','1374581798','9');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','1895398969','1374584748','10');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','1896818869','1374589569','11');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','2105275619','1374592929','12');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','2021656347','1374594141','13');");
E_D("replace into `zyads_adsip23` values('1002','1004','6','14','16','4','15','3080837031','1374594318','14');");

require("../../inc/footer.php");
?>