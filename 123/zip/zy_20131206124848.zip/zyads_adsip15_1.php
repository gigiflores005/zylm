<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip15`;");
E_C("CREATE TABLE `zyads_adsip15` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','1933102497','1373844674','1');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','2084646458','1373851545','2');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','2088693071','1373853092','3');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','2008195350','1373857834','4');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','707865783','1373861111','5');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','3395545940','1373869051','6');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','976816932','1373869205','7');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','3684475152','1373878465','8');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','829690714','1373897512','9');");
E_D("replace into `zyads_adsip15` values('1002','1004','6','14','16','4','15','1927984633','1373899692','10');");

require("../../inc/footer.php");
?>