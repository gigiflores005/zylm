<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip19`;");
E_C("CREATE TABLE `zyads_adsip19` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','976816932','1374200532','1');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','466460073','1374200585','2');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','2072190748','1374212729','3');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','2072453504','1374220530','4');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','1912052235','1374227271','5');");
E_D("replace into `zyads_adsip19` values('1002','1004','1','11','14','4','7','1912052235','1374227281','6');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','3728368624','1374234323','7');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','1969161759','1374239722','8');");
E_D("replace into `zyads_adsip19` values('1016','1004','7','11','18','7','7','1933198885','1374243170','9');");
E_D("replace into `zyads_adsip19` values('1002','1004','6','14','16','4','15','1866174691','1374245947','10');");
E_D("replace into `zyads_adsip19` values('1002','1004','1','11','14','4','7','1866174691','1374245952','11');");

require("../../inc/footer.php");
?>