<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip3`;");
E_C("CREATE TABLE `zyads_adsip3` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','3','2','7','976816932','1370230695','1');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','976816932','1370236669','2');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1928244684','1370239916','3');");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','3','2','7','465405151','1370240891','4');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','465405151','1370240893','5');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','606873189','1370240946','6');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1695588407','1370246370','7');");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','3','2','7','1695588407','1370246377','8');");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','3','2','7','1919528519','1370246458','9');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1919528519','1370246460','10');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2100097600','1370246627','11');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1991951660','1370246753','12');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','3701917646','1370247593','13');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','3733222822','1370247623','14');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1020299847','1370249534','15');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1007031573','1370260474','16');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2027073711','1370260483','17');");
E_D("replace into `zyads_adsip3` values('1002','1004','7','11','13','2','7','1880043434','1370263100','18');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1880043434','1370263102','19');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1895388021','1370266287','20');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2006106427','1370266533','21');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1884381220','1370267094','22');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','3659084231','1370267102','23');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1018879005','1370267197','24');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1007666766','1370268216','25');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2072654849','1370268289','26');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2102937932','1370268928','27');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','3701509836','1370269694','28');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1700172353','1370269721','29');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1902359727','1370270046','30');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2101559335','1370270328','31');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2006180187','1370271127','32');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','3683332975','1370271518','33');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','1778608008','1370272285','34');");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','3','2','7','1778608008','1370272317','35');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2095316584','1370272527','36');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2075727438','1370273819','37');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','12','3','15','2075563536','1370274170','38');");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','3','2','7','2075563536','1370274188','39');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1018198008','1372783932','40');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1894530700','1372811742','41');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1901376290','1372814986','42');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2869447683','1372818900','43');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2007437213','1372819170','44');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2871359727','1372819327','45');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1896652991','1372820226','46');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2032372823','1372820378','47');");
E_D("replace into `zyads_adsip3` values('1002','1004','1','11','14','4','7','2032372823','1372820381','48');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1034351059','1372821216','49');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','465907050','1372821434','50');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1901721724','1372821896','51');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3722528418','1372822472','52');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3395990590','1372823063','53');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3074246508','1372823769','54');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2875863251','1372824169','55');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2875770495','1372824886','56');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3747357736','1372826145','57');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1901631416','1372826580','58');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3063061144','1372828287','59');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2874707466','1372830435','60');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3550482294','1372830872','61');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3737022252','1372832594','62');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1018827358','1372832872','63');");
E_D("replace into `zyads_adsip3` values('1002','1004','7','11','15','4','7','1018827358','1372832879','64');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1912179945','1372833222','65');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3757065408','1372838134','66');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1962868354','1372838498','67');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','827001074','1372838589','68');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3071468538','1372840578','69');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1904576929','1372841472','70');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3071467816','1372855018','71');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3683141372','1372855084','72');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','989350268','1372857823','73');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2026216579','1372860250','74');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','244423212','1372862057','75');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','2069364768','1372863463','76');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','3750800518','1372863765','77');");
E_D("replace into `zyads_adsip3` values('1002','1004','6','14','16','4','15','1996765468','1372865192','78');");

require("../../inc/footer.php");
?>