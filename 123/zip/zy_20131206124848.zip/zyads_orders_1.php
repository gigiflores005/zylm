<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_orders`;");
E_C("CREATE TABLE `zyads_orders` (
  `orderid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) DEFAULT '0',
  `siteid` mediumint(8) NOT NULL DEFAULT '0',
  `zoneid` mediumint(8) DEFAULT '0',
  `planid` mediumint(8) DEFAULT '0',
  `adsid` mediumint(9) DEFAULT '0',
  `price` decimal(12,4) DEFAULT '0.0000',
  `priceadv` decimal(12,4) DEFAULT '0.0000',
  `ip` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `orders` varchar(100) DEFAULT '0',
  `deduction` tinyint(1) DEFAULT '0',
  `like` varchar(255) DEFAULT NULL,
  `status` tinyint(3) DEFAULT '0',
  `day` date DEFAULT '0000-00-00',
  `linkuid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` datetime DEFAULT '0000-00-00 00:00:00',
  `confirmtime` date DEFAULT '0000-00-00',
  PRIMARY KEY (`orderid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_orders` values('1','1020','8','19','16','8','0.8000','1.0000','60.188.216.230','','','0','','1','2013-12-05','0','2013-12-05 23:02:02','0000-00-00');");
E_D("replace into `zyads_orders` values('2','1020','8','27','17','9','0.8000','0.9000','125.127.149.26','','','0','','1','2013-12-06','0','2013-12-06 18:11:42','0000-00-00');");

require("../../inc/footer.php");
?>