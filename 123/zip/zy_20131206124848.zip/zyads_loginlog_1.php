<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_loginlog`;");
E_C("CREATE TABLE `zyads_loginlog` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `logintype` varchar(10) NOT NULL,
  `logininfo` varchar(20) NOT NULL,
  `loginip` char(15) NOT NULL,
  `logintime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_loginlog` values('1','admin','admin','Succe','www.ak345.com','2013-05-09 19:34:17');");
E_D("replace into `zyads_loginlog` values('2','nihao','member','Succe','www.ak345.com','2013-05-09 19:39:23');");
E_D("replace into `zyads_loginlog` values('3','admin','admin','Succe','www.ak345.com','2013-05-09 19:51:11');");
E_D("replace into `zyads_loginlog` values('4','nihaoya','member','Succe','www.ak345.com','2013-05-09 19:52:04');");
E_D("replace into `zyads_loginlog` values('5','admin','admin','Succe','www.ak345.com','2013-05-12 18:55:52');");
E_D("replace into `zyads_loginlog` values('6','nihao','member','Faile','www.ak345.com','2013-05-12 18:56:49');");
E_D("replace into `zyads_loginlog` values('7','nihao','member','Succe','www.ak345.com','2013-05-12 18:57:25');");
E_D("replace into `zyads_loginlog` values('8','admin','admin','Succe','www.ak345.com','2013-05-13 21:49:51');");
E_D("replace into `zyads_loginlog` values('9','nihao','member','Succe','www.ak345.com','2013-05-13 21:52:53');");
E_D("replace into `zyads_loginlog` values('10','admin','admin','Succe','www.ak345.com','2013-05-13 22:09:54');");
E_D("replace into `zyads_loginlog` values('11','admin','admin','Succe','www.ak345.com','2013-05-13 22:16:25');");
E_D("replace into `zyads_loginlog` values('12','admin','admin','Succe','www.ak345.com','2013-05-13 22:18:14');");
E_D("replace into `zyads_loginlog` values('13','admin','admin','Succe','www.ak345.com','2013-05-13 22:23:56');");
E_D("replace into `zyads_loginlog` values('14','admin','admin','Succe','www.ak345.com','2013-05-13 22:27:57');");
E_D("replace into `zyads_loginlog` values('15','admin','admin','Succe','www.ak345.com','2013-05-13 22:37:26');");
E_D("replace into `zyads_loginlog` values('16','admin','admin','Succe','www.ak345.com','2013-05-13 23:12:11');");
E_D("replace into `zyads_loginlog` values('17','admin','admin','Succe','www.ak345.com','2013-05-13 23:18:30');");
E_D("replace into `zyads_loginlog` values('18','admin','admin','Succe','www.ak345.com','2013-05-13 23:27:53');");
E_D("replace into `zyads_loginlog` values('19','admin','admin','Succe','www.ak345.com','2013-05-13 23:49:27');");
E_D("replace into `zyads_loginlog` values('20','admin','admin','Succe','www.ak345.com','2013-05-14 00:28:57');");
E_D("replace into `zyads_loginlog` values('21','admin','admin','Succe','www.ak345.com','2013-05-14 01:14:19');");
E_D("replace into `zyads_loginlog` values('22','admin','admin','Succe','www.ak345.com','2013-05-14 01:14:37');");
E_D("replace into `zyads_loginlog` values('23','admin','admin','Succe','www.ak345.com','2013-05-14 01:46:03');");
E_D("replace into `zyads_loginlog` values('24','nihao','member','Succe','www.ak345.com','2013-05-14 15:14:19');");
E_D("replace into `zyads_loginlog` values('25','admin','admin','Succe','www.ak345.com','2013-05-14 15:15:06');");
E_D("replace into `zyads_loginlog` values('26','nihaoya','member','Faile','www.ak345.com','2013-05-14 15:15:38');");
E_D("replace into `zyads_loginlog` values('27','nihaoya','member','Faile','www.ak345.com','2013-05-14 15:15:53');");
E_D("replace into `zyads_loginlog` values('28','admin','admin','Succe','www.ak345.com','2013-05-14 15:16:13');");
E_D("replace into `zyads_loginlog` values('29','nihaoya','member','Succe','www.ak345.com','2013-05-14 15:17:22');");
E_D("replace into `zyads_loginlog` values('30','admin','admin','Succe','www.ak345.com','2013-05-14 16:00:42');");
E_D("replace into `zyads_loginlog` values('31','admin','admin','Succe','www.ak345.com','2013-05-15 13:38:45');");
E_D("replace into `zyads_loginlog` values('32','nihao','member','Succe','www.ak345.com','2013-05-15 13:42:15');");
E_D("replace into `zyads_loginlog` values('33','nihao','member','Succe','www.ak345.com','2013-05-15 14:32:13');");
E_D("replace into `zyads_loginlog` values('34','nihaoya','member','Succe','www.ak345.com','2013-05-15 14:33:27');");
E_D("replace into `zyads_loginlog` values('35','nihaoya','member','Succe','www.ak345.com','2013-05-15 14:35:12');");
E_D("replace into `zyads_loginlog` values('36','nihao','member','Succe','www.ak345.com','2013-05-15 14:43:24');");
E_D("replace into `zyads_loginlog` values('37','admin','admin','Succe','www.ak345.com','2013-05-15 23:38:59');");
E_D("replace into `zyads_loginlog` values('38','admin','admin','Succe','www.ak345.com','2013-05-18 01:25:17');");
E_D("replace into `zyads_loginlog` values('39','admin','admin','Succe','27.213.3.79','2013-06-02 11:38:42');");
E_D("replace into `zyads_loginlog` values('40','guanggaozhu','member','Succe','27.213.3.79','2013-06-02 11:44:39');");
E_D("replace into `zyads_loginlog` values('41','wangzhanzhu','member','Succe','27.213.3.79','2013-06-02 11:57:44');");
E_D("replace into `zyads_loginlog` values('42','ajjfsfd','member','Faile','46.118.153.7','2013-06-03 00:57:10');");
E_D("replace into `zyads_loginlog` values('43','admin','admin','Succe','58.57.11.36','2013-06-03 11:00:51');");
E_D("replace into `zyads_loginlog` values('44','wangzhanzhu','member','Succe','58.57.11.36','2013-06-03 11:01:42');");
E_D("replace into `zyads_loginlog` values('45','admin','admin','Succe','58.57.11.36','2013-06-03 11:37:28');");
E_D("replace into `zyads_loginlog` values('46','wangzhanzhu','member','Succe','58.57.11.36','2013-06-03 11:40:17');");
E_D("replace into `zyads_loginlog` values('47','admin','member','Faile','101.16.160.55','2013-06-03 16:22:41');");
E_D("replace into `zyads_loginlog` values('48','admin','member','Faile','101.16.160.55','2013-06-03 16:24:18');");
E_D("replace into `zyads_loginlog` values('49','wangzhanzhu','member','Succe','58.57.11.36','2013-06-04 14:39:52');");
E_D("replace into `zyads_loginlog` values('50','wangzhanzhu','member','Succe','119.179.85.4','2013-06-04 20:10:17');");
E_D("replace into `zyads_loginlog` values('51','wangzhanzhu','member','Succe','27.216.7.16','2013-06-07 20:15:45');");
E_D("replace into `zyads_loginlog` values('52','wangzhanzhu','member','Succe','58.57.11.36','2013-06-08 15:45:13');");
E_D("replace into `zyads_loginlog` values('53','admin','admin','Succe','58.57.11.36','2013-06-08 15:48:02');");
E_D("replace into `zyads_loginlog` values('54','wangzhanzhu','member','Succe','58.57.11.36','2013-06-08 17:05:14');");
E_D("replace into `zyads_loginlog` values('55','admin','admin','Succe','222.215.160.187','2013-06-09 12:59:03');");
E_D("replace into `zyads_loginlog` values('56','admin','admin','Succe','58.57.11.36','2013-06-09 12:59:42');");
E_D("replace into `zyads_loginlog` values('57','guanggaozhu','member','Succe','222.215.160.187','2013-06-09 13:00:11');");
E_D("replace into `zyads_loginlog` values('58','guanggaozhu','member','Succe','58.57.11.36','2013-07-01 16:28:52');");
E_D("replace into `zyads_loginlog` values('59','admin','admin','Succe','58.57.11.36','2013-07-01 16:29:27');");
E_D("replace into `zyads_loginlog` values('60','wangzhanzhu','member','Succe','58.57.11.36','2013-07-01 16:39:14');");
E_D("replace into `zyads_loginlog` values('61','admin','admin','Succe','58.57.11.37','2013-07-03 12:56:31');");
E_D("replace into `zyads_loginlog` values('62','admin','admin','Succe','222.137.191.171','2013-07-03 12:57:06');");
E_D("replace into `zyads_loginlog` values('63','zjczz110','member','Faile','222.137.191.171','2013-07-03 13:07:09');");
E_D("replace into `zyads_loginlog` values('64','zjzz110','member','Succe','222.137.191.171','2013-07-03 13:07:17');");
E_D("replace into `zyads_loginlog` values('65','zhanglei','member','Succe','222.137.191.171','2013-07-03 13:13:34');");
E_D("replace into `zyads_loginlog` values('66','sdfsdf2342','member','Succe','14.145.154.44','2013-07-03 22:31:30');");
E_D("replace into `zyads_loginlog` values('67','sdfsdf2342','member','Succe','218.107.8.234','2013-07-03 22:32:36');");
E_D("replace into `zyads_loginlog` values('68','admin','admin','Succe','111.175.56.238','2013-07-04 20:48:09');");
E_D("replace into `zyads_loginlog` values('69','lixianyang','member','Succe','123.85.97.151','2013-07-05 20:36:53');");
E_D("replace into `zyads_loginlog` values('70','DepecheMode','member','Faile','94.27.75.137','2013-07-09 17:19:00');");
E_D("replace into `zyads_loginlog` values('71','DepecheMode','member','Faile','94.27.75.137','2013-07-09 19:13:47');");
E_D("replace into `zyads_loginlog` values('72','DepecheMode','member','Faile','94.27.75.137','2013-07-09 21:37:17');");
E_D("replace into `zyads_loginlog` values('73','DepecheMode','member','Faile','94.27.75.137','2013-07-09 23:03:02');");
E_D("replace into `zyads_loginlog` values('74','DepecheMode','member','Faile','94.27.75.137','2013-07-10 00:29:54');");
E_D("replace into `zyads_loginlog` values('75','admin','admin','Succe','112.237.192.83','2013-07-10 18:56:41');");
E_D("replace into `zyads_loginlog` values('76','admin','admin','Succe','122.240.160.150','2013-07-10 18:57:07');");
E_D("replace into `zyads_loginlog` values('77','admin','admin','Succe','111.161.127.139','2013-07-10 19:44:48');");
E_D("replace into `zyads_loginlog` values('78','Peagguaxeddy','member','Faile','31.129.164.168','2013-07-10 23:56:31');");
E_D("replace into `zyads_loginlog` values('79','wangzhanzhu','member','Succe','112.249.126.57','2013-07-19 20:45:21');");
E_D("replace into `zyads_loginlog` values('80','1231sdad','member','Succe','115.58.70.37','2013-07-19 22:10:32');");
E_D("replace into `zyads_loginlog` values('81','asdsdasd','member','Succe','115.204.167.108','2013-07-20 11:31:57');");
E_D("replace into `zyads_loginlog` values('82','wangzhanzhu','member','Succe','112.249.126.57','2013-07-20 22:16:05');");
E_D("replace into `zyads_loginlog` values('83','alegroprom','member','Faile','46.0.157.129','2013-07-23 16:36:11');");
E_D("replace into `zyads_loginlog` values('84','admin','admin','Succe','112.249.126.57','2013-07-25 21:19:29');");
E_D("replace into `zyads_loginlog` values('85','admin','admin','Succe','115.60.59.61','2013-07-25 21:20:02');");
E_D("replace into `zyads_loginlog` values('86','admin','admin','Succe','115.60.59.61','2013-07-25 22:36:47');");
E_D("replace into `zyads_loginlog` values('87','95555','member','Faile','118.186.15.215','2013-07-26 06:28:47');");
E_D("replace into `zyads_loginlog` values('88','admin','admin','Succe','118.186.15.215','2013-07-26 06:29:32');");
E_D("replace into `zyads_loginlog` values('89','wangzhanzhu','member','Succe','118.186.15.215','2013-07-26 06:43:20');");
E_D("replace into `zyads_loginlog` values('90','admin','admin','Succe','115.60.59.61','2013-07-26 07:27:58');");
E_D("replace into `zyads_loginlog` values('91','wangzhanzhu','member','Succe','58.57.11.36','2013-07-26 10:42:26');");
E_D("replace into `zyads_loginlog` values('92','wangzhanzhu','member','Succe','58.57.11.36','2013-07-26 10:47:05');");
E_D("replace into `zyads_loginlog` values('93','wangzhanzhu','member','Succe','58.57.11.36','2013-07-26 10:51:37');");
E_D("replace into `zyads_loginlog` values('94','wangzhanzhu','member','Succe','58.57.11.36','2013-07-26 10:51:49');");
E_D("replace into `zyads_loginlog` values('95','wangzhanzhu','member','Succe','58.57.11.36','2013-07-26 11:00:44');");
E_D("replace into `zyads_loginlog` values('96','admin','admin','Succe','60.188.216.230','2013-12-05 22:43:36');");
E_D("replace into `zyads_loginlog` values('97','admin','admin','Succe','59.188.242.52','2013-12-05 22:49:08');");
E_D("replace into `zyads_loginlog` values('98','lmycgs','member','Succe','60.188.216.230','2013-12-05 22:52:45');");
E_D("replace into `zyads_loginlog` values('99','lmycgs1','member','Succe','60.188.216.230','2013-12-05 23:01:43');");
E_D("replace into `zyads_loginlog` values('100','lmycgs','member','Succe','59.188.242.52','2013-12-05 23:07:08');");
E_D("replace into `zyads_loginlog` values('101','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:16:53');");
E_D("replace into `zyads_loginlog` values('102','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:25:05');");
E_D("replace into `zyads_loginlog` values('103','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:35:27');");
E_D("replace into `zyads_loginlog` values('104','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:39:11');");
E_D("replace into `zyads_loginlog` values('105','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:40:04');");
E_D("replace into `zyads_loginlog` values('106','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:48:24');");
E_D("replace into `zyads_loginlog` values('107','lmycgs','member','Succe','60.188.216.230','2013-12-05 23:50:15');");
E_D("replace into `zyads_loginlog` values('108','lmycgs','member','Succe','60.188.216.230','2013-12-06 00:27:19');");
E_D("replace into `zyads_loginlog` values('109','lmycgs','member','Succe','60.188.216.230','2013-12-06 01:09:52');");
E_D("replace into `zyads_loginlog` values('110','lmycgs','member','Succe','60.188.216.230','2013-12-06 01:59:09');");
E_D("replace into `zyads_loginlog` values('111','lmycgs','member','Succe','60.188.216.230','2013-12-06 02:15:43');");
E_D("replace into `zyads_loginlog` values('112','lmycgs','member','Succe','60.188.216.230','2013-12-06 02:17:18');");
E_D("replace into `zyads_loginlog` values('113','admin','admin','Succe','60.188.216.230','2013-12-06 03:48:00');");
E_D("replace into `zyads_loginlog` values('114','lmycgs','member','Succe','60.188.216.230','2013-12-06 03:49:56');");
E_D("replace into `zyads_loginlog` values('115','lmycgs','member','Succe','60.188.216.230','2013-12-06 03:50:25');");
E_D("replace into `zyads_loginlog` values('116','lmycgs','member','Succe','60.188.216.230','2013-12-06 03:51:39');");
E_D("replace into `zyads_loginlog` values('117','lmycgs','member','Succe','60.188.216.230','2013-12-06 03:53:03');");
E_D("replace into `zyads_loginlog` values('118','lmycgs','member','Succe','60.188.216.230','2013-12-06 04:02:50');");
E_D("replace into `zyads_loginlog` values('119','admin','admin','Succe','60.188.216.230','2013-12-06 04:38:10');");
E_D("replace into `zyads_loginlog` values('120','lmycgs','member','Succe','125.127.149.26','2013-12-06 13:33:52');");
E_D("replace into `zyads_loginlog` values('121','admin','admin','Succe','125.127.149.26','2013-12-06 13:34:23');");
E_D("replace into `zyads_loginlog` values('122','lmycgs','member','Succe','125.127.149.26','2013-12-06 14:41:33');");
E_D("replace into `zyads_loginlog` values('123','admin','admin','Succe','125.127.149.26','2013-12-06 14:45:50');");
E_D("replace into `zyads_loginlog` values('124','jzn66681','member','Succe','221.0.50.247','2013-12-06 15:49:41');");
E_D("replace into `zyads_loginlog` values('125','lmycgs','member','Succe','125.127.149.26','2013-12-06 16:02:37');");
E_D("replace into `zyads_loginlog` values('126','admin','admin','Succe','125.127.149.26','2013-12-06 16:40:33');");
E_D("replace into `zyads_loginlog` values('127','lmycgs','member','Succe','125.127.149.26','2013-12-06 16:45:15');");
E_D("replace into `zyads_loginlog` values('128','lmycgs','member','Succe','125.127.149.26','2013-12-06 17:05:34');");
E_D("replace into `zyads_loginlog` values('129','lmycgs','member','Succe','125.127.149.26','2013-12-06 17:59:30');");
E_D("replace into `zyads_loginlog` values('130','lmycgs','member','Succe','125.127.149.26','2013-12-06 18:01:22');");
E_D("replace into `zyads_loginlog` values('131','lmycgs2','member','Succe','125.127.149.26','2013-12-06 18:10:35');");
E_D("replace into `zyads_loginlog` values('132','lmycgs','member','Succe','125.127.149.26','2013-12-06 20:20:22');");

require("../../inc/footer.php");
?>