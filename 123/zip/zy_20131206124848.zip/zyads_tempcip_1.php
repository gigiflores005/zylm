<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_tempcip`;");
E_C("CREATE TABLE `zyads_tempcip` (
  `ip` char(15) NOT NULL,
  `planid` mediumint(8) NOT NULL,
  `adsid` mediumint(8) NOT NULL DEFAULT '0',
  `zoneid` mediumint(8) NOT NULL DEFAULT '0',
  `day` date NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  KEY `ip` (`ip`),
  KEY `planid` (`planid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_tempcip` values('27.213.3.79','12','2','5','2013-06-02','0');");
E_D("replace into `zyads_tempcip` values('27.213.3.79','15','5','8','2013-06-02','0');");
E_D("replace into `zyads_tempcip` values('27.213.3.79','14','4','10','2013-06-02','0');");
E_D("replace into `zyads_tempcip` values('58.57.11.36','14','6','12','2013-06-03','0');");
E_D("replace into `zyads_tempcip` values('112.15.47.170','14','6','12','2013-06-03','0');");
E_D("replace into `zyads_tempcip` values('123.138.52.1','14','6','12','2013-06-03','0');");
E_D("replace into `zyads_tempcip` values('106.3.103.136','14','6','12','2013-06-03','0');");
E_D("replace into `zyads_tempcip` values('123.182.150.16','14','6','12','2013-06-03','0');");
E_D("replace into `zyads_tempcip` values('120.82.108.98','14','6','12','2013-06-05','0');");
E_D("replace into `zyads_tempcip` values('58.211.170.14','14','6','12','2013-06-05','0');");
E_D("replace into `zyads_tempcip` values('60.222.34.43','14','6','12','2013-06-06','0');");
E_D("replace into `zyads_tempcip` values('180.153.206.16','14','6','12','2013-06-06','0');");
E_D("replace into `zyads_tempcip` values('27.106.163.12','14','6','12','2013-06-08','0');");
E_D("replace into `zyads_tempcip` values('112.237.13.117','14','6','12','2013-06-08','0');");
E_D("replace into `zyads_tempcip` values('113.129.87.14','14','6','12','2013-06-09','0');");
E_D("replace into `zyads_tempcip` values('113.84.179.34','14','6','16','2013-07-03','0');");
E_D("replace into `zyads_tempcip` values('116.213.224.139','14','6','16','2013-07-06','0');");
E_D("replace into `zyads_tempcip` values('101.226.65.109','14','6','16','2013-07-06','0');");
E_D("replace into `zyads_tempcip` values('117.64.203.120','14','6','16','2013-07-07','0');");
E_D("replace into `zyads_tempcip` values('180.108.169.242','14','6','16','2013-07-09','0');");
E_D("replace into `zyads_tempcip` values('221.13.128.27','14','6','16','2013-07-10','0');");
E_D("replace into `zyads_tempcip` values('122.240.160.150','14','6','16','2013-07-10','0');");
E_D("replace into `zyads_tempcip` values('61.182.48.62','14','6','16','2013-07-10','0');");
E_D("replace into `zyads_tempcip` values('112.242.2.198','14','6','16','2013-07-14','0');");
E_D("replace into `zyads_tempcip` values('110.16.232.250','14','6','16','2013-07-16','0');");
E_D("replace into `zyads_tempcip` values('180.142.244.235','14','6','16','2013-07-16','0');");
E_D("replace into `zyads_tempcip` values('182.142.55.18','14','6','16','2013-07-17','0');");
E_D("replace into `zyads_tempcip` values('183.93.66.114','14','6','16','2013-07-20','0');");
E_D("replace into `zyads_tempcip` values('183.1.130.86','14','6','16','2013-07-20','0');");
E_D("replace into `zyads_tempcip` values('60.55.8.21','14','6','16','2013-07-24','0');");
E_D("replace into `zyads_tempcip` values('222.216.207.21','14','6','16','2013-07-24','0');");
E_D("replace into `zyads_tempcip` values('106.113.200.42','14','6','16','2013-07-25','0');");
E_D("replace into `zyads_tempcip` values('60.188.216.230','16','8','19','2013-12-05','0');");
E_D("replace into `zyads_tempcip` values('60.188.216.230','16','8','21','2013-12-05','0');");
E_D("replace into `zyads_tempcip` values('60.188.216.230','15','5','26','2013-12-05','0');");
E_D("replace into `zyads_tempcip` values('60.188.216.230','14','6','23','2013-12-06','0');");
E_D("replace into `zyads_tempcip` values('125.127.149.26','17','9','27','2013-12-06','0');");

require("../../inc/footer.php");
?>