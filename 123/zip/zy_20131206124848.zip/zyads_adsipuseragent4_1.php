<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipuseragent4`;");
E_C("CREATE TABLE `zyads_adsipuseragent4` (
  `useragent` varchar(1000) DEFAULT NULL,
  `useragentid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`useragentid`),
  KEY `useragent` (`useragent`(500))
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1','1');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)','2');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; SE 2.X MetaSr 1.0)','3');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)','4');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; Alexa Toolbar; .NET CLR 2.0.50727)','5');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1','6');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.94 Safari/537.36','7');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; SE 2.X MetaSr 1.0)','8');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729)','9');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0)','10');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17','11');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)','12');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; KB974488; SE 2.X MetaSr 1.0)','13');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0; MALCJS; QQBrowser/7.3.9825.400)','14');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; LBBROWSER)','15');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; Alexa Toolbar; SE 2.X MetaSr 1.0)','16');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17','17');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; eSobiSubscriber 1.0.0.40; BRI/2; MAAR; Media Center PC 6.0; .NET4.0C; .NET4.0E; SE 2.X MetaSr 1.0)','18');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0)','19');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.802.30 Safari/535.1 SE 2.X MetaSr 1.0','20');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; QQDownload 718; .NET CLR 2.0.50727)','21');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31','22');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1','23');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0 AlexaToolbar/alxf-2.18','24');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C; .NET4.0E)','25');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1521.3 Safari/537.36','26');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; znwb6500)','27');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; SE 2.X MetaSr 1.0)','28');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.12 (KHTML, like Gecko) Maxthon/3.3.6.2000 Chrome/18.0.966.0 Safari/535.12','29');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)','30');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; KB974488)','31');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; QQBrowser/7.3.11251.400)','32');");
E_D("replace into `zyads_adsipuseragent4` values('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)','33');");

require("../../inc/footer.php");
?>