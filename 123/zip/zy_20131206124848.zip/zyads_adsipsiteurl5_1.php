<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipsiteurl5`;");
E_C("CREATE TABLE `zyads_adsipsiteurl5` (
  `siteurl` varchar(1000) DEFAULT NULL,
  `siteurlid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`siteurlid`),
  KEY `siteurl` (`siteurl`(500))
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipsiteurl5` values('http://www.liyuanzhao.com/','1');");
E_D("replace into `zyads_adsipsiteurl5` values('','2');");
E_D("replace into `zyads_adsipsiteurl5` values('http://www.liyuanzhao.com/video/list-8.html','3');");
E_D("replace into `zyads_adsipsiteurl5` values('http://www.egaotv.com/','4');");
E_D("replace into `zyads_adsipsiteurl5` values('http://www.baoxiaotuan.com/','5');");
E_D("replace into `zyads_adsipsiteurl5` values('\\\\&#39; _Zloc \\\\&#39;','6');");
E_D("replace into `zyads_adsipsiteurl5` values('http://www.baoxiaotuan.com/video/show-3478.html','7');");

require("../../inc/footer.php");
?>