<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip24`;");
E_C("CREATE TABLE `zyads_adsip24` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3745529408','1374597485','1');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3757312671','1374599312','2');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2045452012','1374599405','3');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3745529705','1374600474','4');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1902930120','1374603023','5');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3684420029','1374625132','6');");
E_D("replace into `zyads_adsip24` values('1002','1004','1','11','14','4','7','3684420029','1374625193','7');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2064034082','1374628727','8');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2936571531','1374630255','9');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1918189498','1374631017','10');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2059462145','1374638272','12');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3071489463','1374638562','13');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2093065794','1374638612','14');");
E_D("replace into `zyads_adsip24` values('1002','1004','1','11','14','4','7','2093065794','1374638652','15');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1874021325','1374640281','16');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1946263027','1374644369','17');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3080946908','1374645194','18');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2079003278','1374645224','19');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3740491152','1374645630','20');");
E_D("replace into `zyads_adsip24` values('1002','1004','1','11','14','4','7','3740491152','1374645744','21');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3740618631','1374647767','22');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3031369186','1374650628','23');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1921469766','1374651410','24');");
E_D("replace into `zyads_adsip24` values('1002','1004','1','11','14','4','7','1921469766','1374651428','25');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1884423019','1374653440','26');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1010239509','1374657319','27');");
E_D("replace into `zyads_adsip24` values('1002','1004','1','11','14','4','7','1010239509','1374657400','28');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1032300873','1374659529','29');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3031237205','1374660308','30');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1895309613','1374662020','31');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','242236661','1374667051','32');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','3738750741','1374669805','33');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','2032178754','1374671552','34');");
E_D("replace into `zyads_adsip24` values('1002','1004','6','14','16','4','15','1929238873','1374671645','35');");

require("../../inc/footer.php");
?>