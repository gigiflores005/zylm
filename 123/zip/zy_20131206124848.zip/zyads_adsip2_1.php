<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip2`;");
E_C("CREATE TABLE `zyads_adsip2` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip2` values('1002','1004','1','11','3','2','7','466944847','1370149542','1');");
E_D("replace into `zyads_adsip2` values('1002','1004','3','13','9','3','9','466944847','1370150367','2');");
E_D("replace into `zyads_adsip2` values('1002','1004','4','14','10','3','15','466944847','1370150548','3');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','3071061107','1372697610','4');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','1918427679','1372705872','5');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','1967543961','1372717907','6');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','1944055775','1372719952','7');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','1905105932','1372726943','8');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','2008310406','1372732363','9');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','1007522626','1372771797','10');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','1948168226','1372777603','11');");
E_D("replace into `zyads_adsip2` values('1002','1004','6','14','16','4','15','3076312970','1372778093','12');");

require("../../inc/footer.php");
?>