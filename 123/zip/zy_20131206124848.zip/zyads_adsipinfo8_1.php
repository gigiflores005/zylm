<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipinfo8`;");
E_C("CREATE TABLE `zyads_adsipinfo8` (
  `ipinfoid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refererid` int(10) unsigned NOT NULL,
  `siteurlid` int(10) unsigned NOT NULL,
  `useragentid` mediumint(8) unsigned NOT NULL,
  `viewtime` int(11) unsigned NOT NULL DEFAULT '0',
  `deduction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `clicks` int(11) unsigned NOT NULL DEFAULT '0',
  `scrollh` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `plugins` varchar(50) DEFAULT NULL,
  `screen` varchar(15) DEFAULT NULL,
  `price` varchar(9) DEFAULT NULL,
  `priceadv` varchar(9) DEFAULT NULL,
  `xx` varchar(50) DEFAULT NULL,
  `yy` varchar(50) DEFAULT NULL,
  `x` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `y` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `n` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `g` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `t` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ipinfoid`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipinfo8` values('1','1','1','16','1370624075','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('2','1','1','17','1370625691','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('3','4','2','17','1370625691','0','1','784','11.7.700','1440x900','0.07','0.08','469,583','83,85','561','49','2','343','7223');");
E_D("replace into `zyads_adsipinfo8` values('4','1','1','11','1370656708','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('5','1','1','12','1370666443','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('6','1','1','12','1370666841','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('7','1','3','11','1370670167','0','3','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('8','2','2','3','1370670188','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('9','1','1','11','1370677838','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('10','2','2','11','1370679555','0','1','139','11.6.602.180','1400x1050','0.07','0.08','537,523','70,6','431','41','2','125','1563');");
E_D("replace into `zyads_adsipinfo8` values('11','1','1','6','1370681731','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('12','2','4','1','1370682284','0','6','707','11.6.602','1366x768','0.07','0.08','252,118,195,12','60,50,89,47','311','39','4','143','27825');");
E_D("replace into `zyads_adsipinfo8` values('13','1','1','12','1370694702','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('14','2','3','12','1370694714','0','1','139','11.4.402.265','1440x900','0.07','0.08','798,584','26,76','495','33','2','125','6391');");
E_D("replace into `zyads_adsipinfo8` values('15','1','1','3','1370697312','0','7','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('16','1','1','11','1370698112','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('17','1','1','1','1370698343','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('18','1','1','12','1370699036','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('19','1','1','13','1370701779','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('20','5','4','13','1370701780','0','1','577','11.5.502','1366x768','0.07','0.08','464,539','1,89','520','34','2','147','18914');");
E_D("replace into `zyads_adsipinfo8` values('21','1','1','13','1370704215','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('22','1','1','18','1370706678','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('23','1','1','25','1373231738','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('24','1','1','6','1373258754','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('25','1','1','9','1373260634','0','1','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('26','1','1','24','1373261428','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('27','5','4','24','1373261428','0','1','139','11.5.502.110','1680x1050','0.07','0.08','839,899,832,815,894,852,859','88,71,81,86,0,86,74','821','48','7','93','36000');");
E_D("replace into `zyads_adsipinfo8` values('28','1','1','19','1373263874','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('29','1','1','15','1373266068','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('30','1','1','25','1373277989','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('31','2','2','30','1373279742','0','1','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('32','1','1','26','1373281227','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('33','1','1','24','1373286657','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('34','1','1','18','1373287809','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('35','1','1','26','1373289199','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('36','1','1','19','1373294444','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo8` values('37','1','1','27','1373298354','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");

require("../../inc/footer.php");
?>