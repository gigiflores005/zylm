<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_paylog`;");
E_C("CREATE TABLE `zyads_paylog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) DEFAULT NULL,
  `xmoney` varchar(20) DEFAULT NULL,
  `money` varchar(20) DEFAULT NULL,
  `tax` varchar(20) DEFAULT NULL,
  `charges` varchar(20) DEFAULT NULL,
  `pay` varchar(20) DEFAULT NULL,
  `clearingadmin` varchar(20) DEFAULT NULL,
  `paytime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scale` double(8,2) NOT NULL DEFAULT '0.00',
  `realmoney` double(10,4) NOT NULL DEFAULT '0.0000',
  `payinfo` mediumtext,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` date NOT NULL DEFAULT '0000-00-00',
  `clearingtype` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique` (`uid`,`addtime`,`clearingtype`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>