<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipsiteurl4`;");
E_C("CREATE TABLE `zyads_adsipsiteurl4` (
  `siteurl` varchar(1000) DEFAULT NULL,
  `siteurlid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`siteurlid`),
  KEY `siteurl` (`siteurl`(500))
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipsiteurl4` values('','1');");
E_D("replace into `zyads_adsipsiteurl4` values('http://www.liyuanzhao.com/','2');");
E_D("replace into `zyads_adsipsiteurl4` values('http://www.liyuanzhao.com/video/show-4257.html','3');");
E_D("replace into `zyads_adsipsiteurl4` values('http://www.baoxiaotuan.com/video/show-4545.html','4');");
E_D("replace into `zyads_adsipsiteurl4` values('http://www.baoxiaotuan.com/','5');");
E_D("replace into `zyads_adsipsiteurl4` values('http://www.baoxiaotuan.com/video/show-3509.html','6');");

require("../../inc/footer.php");
?>