<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_site`;");
E_C("CREATE TABLE `zyads_site` (
  `siteid` int(9) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) NOT NULL,
  `sitename` varchar(200) NOT NULL,
  `siteurl` varchar(200) NOT NULL,
  `pertainurl` mediumtext,
  `sitetype` varchar(100) NOT NULL,
  `siteinfo` varchar(100) DEFAULT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT '1',
  `age` tinyint(1) NOT NULL DEFAULT '1',
  `occupation` tinyint(1) NOT NULL DEFAULT '1',
  `income` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `denyinfo` varchar(255) DEFAULT NULL,
  `alexapr` varchar(20) DEFAULT '0',
  `alexa` mediumint(8) NOT NULL DEFAULT '0',
  `pr` tinyint(3) NOT NULL DEFAULT '0',
  `beian` varchar(30) DEFAULT NULL,
  `grade` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` datetime NOT NULL,
  PRIMARY KEY (`siteid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_site` values('11','1024','12121','dsdsds.com','www.dsdsds.com','111','','1','1','1','1','3',NULL,'0','0','0','','0','2013-12-06 18:11:41');");
E_D("replace into `zyads_site` values('8','1020','1321','dddd.com','www.dddd.com','113','','1','1','1','1','3',NULL,'0','0','0','','0','2013-12-05 22:54:04');");
E_D("replace into `zyads_site` values('10','1020','AK����','ak345.com','www.ak345.com','113','','1','1','1','1','3',NULL,'0','0','0','','0','2013-12-06 18:05:06');");

require("../../inc/footer.php");
?>