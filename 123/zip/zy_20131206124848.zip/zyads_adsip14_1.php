<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip14`;");
E_C("CREATE TABLE `zyads_adsip14` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','460174628','1373734494','1');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','1894908614','1373736016','2');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','2746478260','1373782008','3');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','244403031','1373784026','4');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','1894049946','1373784626','5');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','1948039220','1373785108','6');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','1999107970','1373798257','7');");
E_D("replace into `zyads_adsip14` values('1002','1004','1','11','14','4','7','620472250','1373811788','8');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','620472250','1373811792','9');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','2067098514','1373817415','10');");
E_D("replace into `zyads_adsip14` values('1002','1004','6','14','16','4','15','3029313750','1373817521','11');");
E_D("replace into `zyads_adsip14` values('1002','1004','1','11','14','4','7','3029313750','1373817584','12');");

require("../../inc/footer.php");
?>