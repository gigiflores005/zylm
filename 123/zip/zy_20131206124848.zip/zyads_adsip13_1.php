<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip13`;");
E_C("CREATE TABLE `zyads_adsip13` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','2102462125','1373646155','1');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','2105315575','1373685905','2');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','2095996466','1373697008','3');");
E_D("replace into `zyads_adsip13` values('1002','1004','7','11','15','4','7','1778916877','1373697817','4');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','1895398969','1373699051','5');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','1872842219','1373706651','6');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','3745627240','1373724574','7');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','1036149469','1373725962','8');");
E_D("replace into `zyads_adsip13` values('1002','1004','6','14','16','4','15','1999211401','1373727984','9');");

require("../../inc/footer.php");
?>