<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_admin`;");
E_C("CREATE TABLE `zyads_admin` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL,
  `usertype` tinyint(1) NOT NULL DEFAULT '0',
  `userinfo` varchar(200) NOT NULL,
  `loginnum` mediumint(8) NOT NULL DEFAULT '0',
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `loginip` char(15) NOT NULL,
  `adminaction` mediumtext NOT NULL,
  `addtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_admin` values('1','admin','3f731f38f5c39a6e7c1015246dd818f3','1','','50','2013-12-06 16:40:33','1','125.127.149.26','N;','2013-05-09 19:30:31');");

require("../../inc/footer.php");
?>