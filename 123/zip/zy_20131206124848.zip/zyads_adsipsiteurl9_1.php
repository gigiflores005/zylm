<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipsiteurl9`;");
E_C("CREATE TABLE `zyads_adsipsiteurl9` (
  `siteurl` varchar(1000) DEFAULT NULL,
  `siteurlid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`siteurlid`),
  KEY `siteurl` (`siteurl`(500))
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipsiteurl9` values('','1');");
E_D("replace into `zyads_adsipsiteurl9` values('http://www.liyuanzhao.com/','2');");
E_D("replace into `zyads_adsipsiteurl9` values('http://www.baoxiaotuan.com/video/show-4156.html','3');");
E_D("replace into `zyads_adsipsiteurl9` values('http://www.baoxiaotuan.com/','4');");
E_D("replace into `zyads_adsipsiteurl9` values('http://www.baoxiaotuan.com/video/show-3509.html','5');");

require("../../inc/footer.php");
?>