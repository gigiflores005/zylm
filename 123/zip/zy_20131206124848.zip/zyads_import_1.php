<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_import`;");
E_C("CREATE TABLE `zyads_import` (
  `importid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) NOT NULL,
  `planid` mediumint(9) NOT NULL,
  `num` mediumint(9) NOT NULL DEFAULT '1',
  `adfnum` mediumint(9) NOT NULL DEFAULT '0',
  `orders` varchar(255) DEFAULT NULL,
  `userproportion` tinyint(3) NOT NULL DEFAULT '0',
  `advproportion` tinyint(3) NOT NULL DEFAULT '0',
  `userprice` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `advprice` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `sumpay` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `sumadvpay` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `sumprofit` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `ordersprices` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `day` date NOT NULL,
  `addtime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`importid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_import` values('1','1012','15','30','0','','0','0','1.0000','2.0000','30.0000','60.0000','30.0000','0.0000','2013-07-23','2013-07-26 06:41:54','0');");

require("../../inc/footer.php");
?>