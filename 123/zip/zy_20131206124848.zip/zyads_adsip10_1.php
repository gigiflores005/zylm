<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsip10`;");
E_C("CREATE TABLE `zyads_adsip10` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `advuid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adsid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `planid` mediumint(8) unsigned DEFAULT '0',
  `zoneid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adstypeid` mediumint(8) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `clicktime` int(11) unsigned NOT NULL,
  `ipinfoid` int(11) unsigned NOT NULL,
  UNIQUE KEY `pi_id` (`ip`,`planid`),
  KEY `ip` (`ip`),
  KEY `uid` (`uid`),
  KEY `adsid` (`adsid`),
  KEY `clicktime` (`clicktime`),
  KEY `adstypeid` (`adstypeid`),
  KEY `planid` (`planid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','1902649201','1373413219','1');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','3072529637','1373424005','2');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','1964921105','1373428353','3');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','3396262005','1373429829','4');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','976816932','1373435931','5');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','1035350078','1373442447','6');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','1017491594','1373443625','7');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','1908588595','1373444181','8');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','2052217645','1373444352','9');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','3708649499','1373445821','10');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','3670905603','1373445857','11');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','2062590102','1373453611','12');");
E_D("replace into `zyads_adsip10` values('1002','1004','1','11','14','4','7','2062590102','1373453658','13');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','1872854923','1373457525','14');");
E_D("replace into `zyads_adsip10` values('1002','1004','7','11','15','4','7','1872854923','1373457526','15');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','3701687977','1373459641','16');");
E_D("replace into `zyads_adsip10` values('1002','1004','6','14','16','4','15','2876124677','1373470447','17');");

require("../../inc/footer.php");
?>