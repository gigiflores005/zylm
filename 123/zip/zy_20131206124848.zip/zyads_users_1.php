<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_users`;");
E_C("CREATE TABLE `zyads_users` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` char(32) NOT NULL,
  `question` varchar(20) NOT NULL,
  `answer` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `qq` varchar(11) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `accountname` varchar(120) NOT NULL,
  `bank` varchar(20) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `bankacc` varchar(120) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `company` varchar(100) DEFAULT NULL,
  `companyinfo` varchar(100) DEFAULT NULL,
  `recommend` varchar(8) DEFAULT NULL COMMENT '?????',
  `regtime` datetime NOT NULL,
  `regip` char(15) NOT NULL,
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `loginnum` mediumint(8) NOT NULL DEFAULT '0',
  `loginip` char(15) NOT NULL DEFAULT '0.0.0.0',
  `cpmdeduction` tinyint(3) NOT NULL DEFAULT '0',
  `cpcdeduction` tinyint(3) NOT NULL DEFAULT '0',
  `cpadeduction` tinyint(3) NOT NULL DEFAULT '0',
  `cpsdeduction` tinyint(3) NOT NULL DEFAULT '0',
  `cpvdeduction` tinyint(3) NOT NULL DEFAULT '0',
  `money` double(12,4) DEFAULT '0.0000',
  `daymoney` double(12,4) NOT NULL DEFAULT '0.0000',
  `weekmoney` double(12,4) DEFAULT '0.0000',
  `monthmoney` double(12,4) DEFAULT '0.0000',
  `xmoney` double(12,4) NOT NULL DEFAULT '0.0000',
  `integral` int(10) unsigned NOT NULL DEFAULT '0',
  `activateid` varchar(11) NOT NULL,
  `clusterid` tinyint(3) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `userinfo` varchar(200) DEFAULT NULL,
  `view` mediumint(8) NOT NULL DEFAULT '0',
  `pvstep` smallint(4) NOT NULL DEFAULT '0',
  `serviceid` mediumint(8) NOT NULL DEFAULT '0',
  `nums` mediumint(8) NOT NULL DEFAULT '0',
  `cpczlink` tinyint(1) NOT NULL DEFAULT '1',
  `cpazlink` tinyint(1) NOT NULL DEFAULT '1',
  `cpszlink` tinyint(1) NOT NULL DEFAULT '1',
  `cpmzlink` tinyint(1) NOT NULL DEFAULT '1',
  `insite` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `type` (`type`),
  KEY `daymoney` (`daymoney`),
  KEY `weekmoney` (`weekmoney`),
  KEY `monthmoney` (`monthmoney`),
  KEY `serviceid` (`serviceid`)
) ENGINE=MyISAM AUTO_INCREMENT=1025 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_users` values('1003','xiaoli','e10adc3949ba59abbe56e057f20f883e','','','','1211628405','','','','','','','����','','','0','2013-06-02 11:43:13','27.213.3.79','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','','0','3','2','','0','0','0','0','0','0','0','0','0');");
E_D("replace into `zyads_users` values('1005','xiaoliu','e10adc3949ba59abbe56e057f20f883e','','','','1211628405','','','','','','','����','','','0','2013-06-02 11:44:23','27.213.3.79','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','','0','4','2','','0','0','0','0','0','0','0','0','0');");
E_D("replace into `zyads_users` values('1006','AlexledovichA','664ff28c0d5b3df0436af2b0c554c96a','','on','alexledovicha@yandex.ru','','123456','','AlexledovichA','icbc','AlexledovichA','','alexledovi',NULL,NULL,'','2013-06-02 18:25:57','212.3.128.193','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1370168757','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1007','ajjfsfd','1e3bdd61cb10d61bdfcf955a1543772d','','on','lidka_arutyunova@mail.ru','','123456','','ajjfsfd','icbc','ajjfsfd','','lidka_arut',NULL,NULL,'','2013-06-03 00:57:05','46.118.153.7','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1370192225','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1008','PiomePhew','4012933a877438b5f752d381ccb92d3b','','on','clieplaps@hotmail.com','','123456','','PiomePhew','icbc','PiomePhew','','clieplaps@',NULL,NULL,'','2013-06-06 20:52:10','95.158.246.206','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1370523130','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1009','Marieralinvex','f23b1deef90a027537f3b8cab721ca3e','','on','weestotly@hotmail.com','','123456','','Marieralinvex','icbc','Marieralinvex','','weestotly@',NULL,NULL,'','2013-06-09 02:42:05','95.158.224.242','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1370716925','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1024','lmycgs2','e7de33bd2f5ccb2a18e3f825f5cdd9dd','1231','3213','132132@qq.com','132','','','121','alipay','','1212eeee','2132',NULL,NULL,'','2013-12-06 18:10:19','125.127.149.26','2013-12-06 18:10:35','1','125.127.149.26','0','0','0','0','0','0.0000','1.0000','0.0000','0.0000','0.0000','0','1386324619','0','1','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1014','DepecheMode','f914e7c6643947034fbe902a575b03a1','','on','depechemodet@yandex.ru','','123456','','DepecheMode','icbc','DepecheMode','','depechemod',NULL,NULL,'','2013-07-07 14:05:43','94.27.65.140','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1373177143','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1015','Peagguaxeddy','8f9bec85a6c244df696db4fdabd7cbbb','','on','eagedgesaild@hotmail.com','','123456','','Peagguaxeddy','icbc','Peagguaxeddy','','eagedgesai',NULL,NULL,'','2013-07-08 02:09:17','62.122.64.198','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1373220557','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1018','alegroprom','b20f1481e350553663dbc0e5d05b02f3','','on','alegromexx@mail.ru','','123456','','alegroprom','icbc','alegroprom','','alegromexx',NULL,NULL,'','2013-07-23 16:36:04','46.0.157.129','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1374568564','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1019','jokelnunc','bec112b7005feb305076492a13e5207e','','on','willymakeltos@mail.ru','','123456','','jokelnunc','icbc','jokelnunc','','willymakel',NULL,NULL,'','2013-07-24 14:36:28','195.62.25.197','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','0.0000','0.0000','0.0000','0.0000','0.0000','0','1374647788','0','0','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1020','lmycgs','e7de33bd2f5ccb2a18e3f825f5cdd9dd','43212','132','132132@qq.com','132132','','','1321','icbc','23132','132123','132',NULL,NULL,'','2013-12-05 22:52:28','60.188.216.230','2013-12-06 20:20:22','27','125.127.149.26','0','0','0','0','0','0.0000','1.8000','0.8900','0.0000','0.0000','0','1386255148','0','1','2','','0','0','0','5','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1023','lmycgs1','e7de33bd2f5ccb2a18e3f825f5cdd9dd','','','','','','','','','','','',NULL,NULL,NULL,'2013-12-06 16:52:49','125.127.149.26','0000-00-00 00:00:00','0','0.0.0.0','0','0','0','0','0','99999.1000','0.0000','0.0000','0.0000','0.0000','0','','0','2','2',NULL,'0','0','0','0','1','1','1','1','1');");
E_D("replace into `zyads_users` values('1022','jzn66681','4b45d7ae126e85ea50299e2e968821ea','�ҵ����','�ֵ�','1585757110@qq.com','1585757110','','','�ֱ���','alipay','','905066681@qq.com','�ֱ���',NULL,NULL,'','2013-12-06 15:49:07','221.0.50.247','2013-12-06 15:49:41','1','221.0.50.247','0','0','0','0','0','0.0000','10.0000','0.0000','0.0000','0.0000','0','1386316147','0','1','2',NULL,'0','0','1003','0','1','1','1','1','1');");

require("../../inc/footer.php");
?>