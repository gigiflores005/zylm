<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipreferer1`;");
E_C("CREATE TABLE `zyads_adsipreferer1` (
  `referer` varchar(1000) DEFAULT NULL,
  `refererid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`refererid`),
  KEY `referer` (`referer`(500))
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipreferer1` values('','1');");
E_D("replace into `zyads_adsipreferer1` values('http://bbs.admin5.com/forum.php?mod=viewthread&tid=12188752&extra=page%3D3%26filter%3Dsortid%26sortid%3D310%26sortid%3D310','2');");
E_D("replace into `zyads_adsipreferer1` values('http://www.baoxiaotuan.com/','3');");
E_D("replace into `zyads_adsipreferer1` values('http://www.baoxiaotuan.com/video/show-4384.html','4');");
E_D("replace into `zyads_adsipreferer1` values('http://www.admin5.net/thread-8445006-1-1.html','5');");
E_D("replace into `zyads_adsipreferer1` values('http://www.admin5.net/forum.php?mod=viewthread&tid=12188752&extra=page%3D1%26filter%3Dsortid%26sortid%3D310%26sortid%3D310','6');");
E_D("replace into `zyads_adsipreferer1` values('http://www.baoxiaotuan.com/video/list-4.html','7');");

require("../../inc/footer.php");
?>