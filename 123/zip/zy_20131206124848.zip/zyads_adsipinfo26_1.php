<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipinfo26`;");
E_C("CREATE TABLE `zyads_adsipinfo26` (
  `ipinfoid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refererid` int(10) unsigned NOT NULL,
  `siteurlid` int(10) unsigned NOT NULL,
  `useragentid` mediumint(8) unsigned NOT NULL,
  `viewtime` int(11) unsigned NOT NULL DEFAULT '0',
  `deduction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `clicks` int(11) unsigned NOT NULL DEFAULT '0',
  `scrollh` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `plugins` varchar(50) DEFAULT NULL,
  `screen` varchar(15) DEFAULT NULL,
  `price` varchar(9) DEFAULT NULL,
  `priceadv` varchar(9) DEFAULT NULL,
  `xx` varchar(50) DEFAULT NULL,
  `yy` varchar(50) DEFAULT NULL,
  `x` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `y` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `n` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `g` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `t` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ipinfoid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipinfo26` values('1','1','1','23','1374773458','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo26` values('2','1','1','15','1374774326','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo26` values('3','2','2','44','1374780337','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo26` values('4','8','7','44','1374780360','0','1','809','11.5.502','1600x900','0.07','0.08','316,103,634','73,88,3','616','45','3','1646','10608');");
E_D("replace into `zyads_adsipinfo26` values('5','1','1','32','1374799775','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo26` values('6','1','1','30','1374806935','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");

require("../../inc/footer.php");
?>