<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_sessions`;");
E_C("CREATE TABLE `zyads_sessions` (
  `session_id` char(32) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `session_expires` int(10) unsigned NOT NULL DEFAULT '0',
  `session_data` text,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");
E_D("replace into `zyads_sessions` values('9983ut36pr6a9qermf35pn1a45','1386335985','imgcode|s:4:\"GWMK\";serviceqq|s:10:\"1211628405\";username|s:6:\"lmycgs\";password|s:32:\"e7de33bd2f5ccb2a18e3f825f5cdd9dd\";usertype|s:1:\"1\";uid|s:4:\"1020\";userhash|s:8:\"313a21aa\";l_ip|s:14:\"125.127.149.26\";l_time|s:19:\"2013-12-06 17:59:30\";adminusername|s:5:\"admin\";adminpassword|s:32:\"3f731f38f5c39a6e7c1015246dd818f3\";adminuid|N;adminusertype|s:1:\"1\";adminhash|s:8:\"58d181fc\";');");
E_D("replace into `zyads_sessions` values('g81ficvj7goh5alg0v6oj3acu5','1386334445','imgcode|s:4:\"QQDU\";serviceqq|s:10:\"1211628405\";username|s:6:\"lmycgs\";password|s:32:\"e7de33bd2f5ccb2a18e3f825f5cdd9dd\";usertype|s:1:\"1\";uid|s:4:\"1020\";userhash|s:8:\"313a21aa\";l_ip|s:14:\"125.127.149.26\";l_time|s:19:\"2013-12-06 18:01:22\";');");

require("../../inc/footer.php");
?>