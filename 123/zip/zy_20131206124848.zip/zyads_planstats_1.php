<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_planstats`;");
E_C("CREATE TABLE `zyads_planstats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `views` int(10) NOT NULL DEFAULT '0',
  `clicks` int(10) NOT NULL DEFAULT '0',
  `num` int(10) NOT NULL DEFAULT '0',
  `orders` int(10) NOT NULL DEFAULT '0',
  `do2click` int(10) NOT NULL DEFAULT '0',
  `deduction` int(10) NOT NULL DEFAULT '0',
  `sumprofit` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `sumpay` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `sumadvpay` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `planid` int(10) NOT NULL DEFAULT '0',
  `plantype` char(3) NOT NULL,
  `uid` mediumint(8) NOT NULL DEFAULT '0',
  `day` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique` (`day`,`planid`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_planstats` values('1','21','0','0','0','0','1','0.0800','0.0000','0.0800','11','cpc','1004','2013-06-02');");
E_D("replace into `zyads_planstats` values('2','21','1','0','0','0','0','0.0000','0.0000','0.0000','12','cps','1004','2013-06-02');");
E_D("replace into `zyads_planstats` values('3','1','0','1','0','0','0','0.0010','0.0050','0.0060','13','cpm','1004','2013-06-02');");
E_D("replace into `zyads_planstats` values('4','0','1','1','0','0','0','0.0010','0.0050','0.0060','14','cpv','1004','2013-06-02');");
E_D("replace into `zyads_planstats` values('5','0','1','0','0','0','0','0.0000','0.0000','0.0000','15','cpa','1004','2013-06-02');");
E_D("replace into `zyads_planstats` values('6','141','0','6','0','0','1','0.1400','0.4200','0.5600','11','cpc','1004','2013-06-03');");
E_D("replace into `zyads_planstats` values('7','90','5','32','0','0','0','0.0320','0.1600','0.1920','14','cpv','1004','2013-06-03');");
E_D("replace into `zyads_planstats` values('8','261','0','5','0','0','0','0.0500','0.3500','0.4000','11','cpc','1004','2013-06-04');");
E_D("replace into `zyads_planstats` values('9','150','0','45','0','0','0','0.0450','0.2250','0.2700','14','cpv','1004','2013-06-04');");
E_D("replace into `zyads_planstats` values('10','0','0','1','0','0','0','0.0010','0.0050','0.0060','13','cpm','1004','2013-06-04');");
E_D("replace into `zyads_planstats` values('11','140','1','29','0','0','0','0.0290','0.1450','0.1740','14','cpv','1004','2013-06-05');");
E_D("replace into `zyads_planstats` values('12','180','0','6','0','0','0','0.0600','0.4200','0.4800','11','cpc','1004','2013-06-05');");
E_D("replace into `zyads_planstats` values('13','221','0','4','0','0','0','0.0400','0.2800','0.3200','11','cpc','1004','2013-06-06');");
E_D("replace into `zyads_planstats` values('14','20','2','17','0','0','0','0.0170','0.0850','0.1020','14','cpv','1004','2013-06-06');");
E_D("replace into `zyads_planstats` values('15','141','0','4','0','0','0','0.0400','0.2800','0.3200','11','cpc','1004','2013-06-07');");
E_D("replace into `zyads_planstats` values('16','80','0','20','0','0','0','0.0200','0.1000','0.1200','14','cpv','1004','2013-06-07');");
E_D("replace into `zyads_planstats` values('17','280','2','17','0','0','0','0.0170','0.0850','0.1020','14','cpv','1004','2013-06-08');");
E_D("replace into `zyads_planstats` values('18','641','0','5','0','0','0','0.0500','0.3500','0.4000','11','cpc','1004','2013-06-08');");
E_D("replace into `zyads_planstats` values('19','91','1','9','0','0','0','0.0090','0.0450','0.0540','14','cpv','1004','2013-06-09');");
E_D("replace into `zyads_planstats` values('20','131','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-06-09');");
E_D("replace into `zyads_planstats` values('21','41','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-01');");
E_D("replace into `zyads_planstats` values('22','10','0','5','0','0','0','0.0050','0.0250','0.0300','14','cpv','1004','2013-07-01');");
E_D("replace into `zyads_planstats` values('23','0','0','9','0','0','0','0.0090','0.0450','0.0540','14','cpv','1004','2013-07-02');");
E_D("replace into `zyads_planstats` values('24','111','0','0','0','0','0','0.0000','0.0000','0.0000','11','cpc','1004','2013-07-02');");
E_D("replace into `zyads_planstats` values('25','271','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-03');");
E_D("replace into `zyads_planstats` values('26','200','1','37','0','0','0','0.0370','0.1850','0.2220','14','cpv','1004','2013-07-03');");
E_D("replace into `zyads_planstats` values('27','71','0','0','0','0','0','0.0000','0.0000','0.0000','11','cpc','1004','2013-07-04');");
E_D("replace into `zyads_planstats` values('28','70','0','12','0','0','0','0.0120','0.0600','0.0720','14','cpv','1004','2013-07-04');");
E_D("replace into `zyads_planstats` values('29','110','0','14','0','0','0','0.0140','0.0700','0.0840','14','cpv','1004','2013-07-05');");
E_D("replace into `zyads_planstats` values('30','111','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-05');");
E_D("replace into `zyads_planstats` values('31','441','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-06');");
E_D("replace into `zyads_planstats` values('32','60','2','15','0','0','0','0.0150','0.0750','0.0900','14','cpv','1004','2013-07-06');");
E_D("replace into `zyads_planstats` values('33','60','1','8','0','0','0','0.0080','0.0400','0.0480','14','cpv','1004','2013-07-07');");
E_D("replace into `zyads_planstats` values('34','391','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-07');");
E_D("replace into `zyads_planstats` values('35','131','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-08');");
E_D("replace into `zyads_planstats` values('36','80','0','14','0','0','0','0.0140','0.0700','0.0840','14','cpv','1004','2013-07-08');");
E_D("replace into `zyads_planstats` values('37','161','0','4','0','0','0','0.0400','0.2800','0.3200','11','cpc','1004','2013-07-09');");
E_D("replace into `zyads_planstats` values('38','81','1','11','0','0','0','0.0110','0.0550','0.0660','14','cpv','1004','2013-07-09');");
E_D("replace into `zyads_planstats` values('39','101','3','15','0','0','0','0.0150','0.0750','0.0900','14','cpv','1004','2013-07-10');");
E_D("replace into `zyads_planstats` values('40','171','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-10');");
E_D("replace into `zyads_planstats` values('41','50','0','7','0','0','0','0.0070','0.0350','0.0420','14','cpv','1004','2013-07-11');");
E_D("replace into `zyads_planstats` values('42','51','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-11');");
E_D("replace into `zyads_planstats` values('43','10','0','3','0','0','0','0.0030','0.0150','0.0180','14','cpv','1004','2013-07-12');");
E_D("replace into `zyads_planstats` values('44','1','0','0','0','0','0','0.0000','0.0000','0.0000','11','cpc','1004','2013-07-12');");
E_D("replace into `zyads_planstats` values('45','30','0','8','0','0','0','0.0080','0.0400','0.0480','14','cpv','1004','2013-07-13');");
E_D("replace into `zyads_planstats` values('46','81','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-13');");
E_D("replace into `zyads_planstats` values('47','160','1','10','0','0','0','0.0100','0.0500','0.0600','14','cpv','1004','2013-07-14');");
E_D("replace into `zyads_planstats` values('48','171','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-14');");
E_D("replace into `zyads_planstats` values('49','51','0','10','0','0','0','0.0100','0.0500','0.0600','14','cpv','1004','2013-07-15');");
E_D("replace into `zyads_planstats` values('50','331','0','0','0','0','0','0.0000','0.0000','0.0000','11','cpc','1004','2013-07-15');");
E_D("replace into `zyads_planstats` values('51','171','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-16');");
E_D("replace into `zyads_planstats` values('52','21','2','5','0','0','0','0.0050','0.0250','0.0300','14','cpv','1004','2013-07-16');");
E_D("replace into `zyads_planstats` values('53','141','1','8','0','0','0','0.0080','0.0400','0.0480','14','cpv','1004','2013-07-17');");
E_D("replace into `zyads_planstats` values('54','171','0','3','0','0','0','0.0300','0.2100','0.2400','11','cpc','1004','2013-07-17');");
E_D("replace into `zyads_planstats` values('55','61','0','6','0','0','0','0.0060','0.0300','0.0360','14','cpv','1004','2013-07-18');");
E_D("replace into `zyads_planstats` values('56','251','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-18');");
E_D("replace into `zyads_planstats` values('57','41','0','8','0','0','0','0.0080','0.0400','0.0480','14','cpv','1004','2013-07-19');");
E_D("replace into `zyads_planstats` values('58','141','0','3','0','0','0','0.0300','0.2100','0.2400','11','cpc','1004','2013-07-19');");
E_D("replace into `zyads_planstats` values('59','60','2','11','0','0','0','0.0110','0.0550','0.0660','14','cpv','1004','2013-07-20');");
E_D("replace into `zyads_planstats` values('60','181','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-20');");
E_D("replace into `zyads_planstats` values('61','121','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-21');");
E_D("replace into `zyads_planstats` values('62','41','0','7','0','0','0','0.0070','0.0350','0.0420','14','cpv','1004','2013-07-21');");
E_D("replace into `zyads_planstats` values('63','41','0','0','0','0','0','0.0000','0.0000','0.0000','11','cpc','1004','2013-07-22');");
E_D("replace into `zyads_planstats` values('64','30','0','9','0','0','0','0.0090','0.0450','0.0540','14','cpv','1004','2013-07-22');");
E_D("replace into `zyads_planstats` values('65','61','0','13','0','0','0','0.0130','0.0650','0.0780','14','cpv','1004','2013-07-23');");
E_D("replace into `zyads_planstats` values('66','51','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-23');");
E_D("replace into `zyads_planstats` values('67','251','2','29','0','0','0','0.0290','0.1450','0.1740','14','cpv','1004','2013-07-24');");
E_D("replace into `zyads_planstats` values('68','201','0','5','0','0','0','0.0500','0.3500','0.4000','11','cpc','1004','2013-07-24');");
E_D("replace into `zyads_planstats` values('69','91','1','21','0','0','0','0.0210','0.1050','0.1260','14','cpv','1004','2013-07-25');");
E_D("replace into `zyads_planstats` values('70','171','0','2','0','0','0','0.0200','0.1400','0.1600','11','cpc','1004','2013-07-25');");
E_D("replace into `zyads_planstats` values('71','51','0','5','0','0','0','0.0050','0.0250','0.0300','14','cpv','1004','2013-07-26');");
E_D("replace into `zyads_planstats` values('72','31','0','1','0','0','0','0.0100','0.0700','0.0800','11','cpc','1004','2013-07-26');");
E_D("replace into `zyads_planstats` values('73','0','0','30','0','0','0','30.0000','30.0000','60.0000','15','cpa','1004','2013-07-23');");
E_D("replace into `zyads_planstats` values('82','0','1','1','0','0','0','0.1000','0.8000','0.9000','17','cpa','1023','2013-12-06');");

require("../../inc/footer.php");
?>