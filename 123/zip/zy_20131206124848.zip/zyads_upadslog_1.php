<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_upadslog`;");
E_C("CREATE TABLE `zyads_upadslog` (
  `uplogid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `adsid` mediumint(9) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `adstype` char(4) NOT NULL,
  `adstypeid` mediumint(8) NOT NULL,
  `olddata` mediumtext NOT NULL,
  `updata` mediumtext NOT NULL,
  `addtime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uplogid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_upadslog` values('1','1','admin','','7','YTo1OntzOjM6InVybCI7czoyNToiaHR0cDovL3d3dy5saXl1YW56aGFvLmNvbSI7czo4OiJpbWFnZXVybCI7czozNjoiL2EvMjAxMy0wNi0wMi8xMzcwMTQ1NDM4NzM5NjIyMjIuZ2lmIjtzOjU6IndpZHRoIjtzOjM6Ijk1MCI7czo2OiJoZWlnaHQiO3M6MjoiOTAiO3M6NjoiYWRpbmZvIjtzOjA6IiI7fQ==','YTo1OntzOjM6InVybCI7czoyNToiaHR0cDovL3d3dy5saXl1YW56aGFvLmNvbSI7czo4OiJpbWFnZXVybCI7czozNjoiL2EvMjAxMy0wNi0wMy8xMzcwMjM1NTU1MjE2NDI1NzUuZ2lmIjtzOjU6IndpZHRoIjtpOjk1MDtzOjY6ImhlaWdodCI7aTo5MDtzOjY6ImFkaW5mbyI7czowOiIiO30=','2013-06-03 12:59:15','1');");
E_D("replace into `zyads_upadslog` values('2','8','admin','','16','YToyOntzOjM6InVybCI7czoxODoiaHR0cDovL3d3dy5mdzg4LmNuIjtzOjg6ImltYWdldXJsIjtzOjM2OiIvYS8yMDEzLTA3LTAzLzEzNzI4MjgyOTI3NjgxNzA0NC5naWYiO30=','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:46:27','1');");
E_D("replace into `zyads_upadslog` values('3','7','admin','','7','YToyOntzOjM6InVybCI7czoxNzoiaHR0cDovL2Nhb25pbWEucnUiO3M6ODoiaW1hZ2V1cmwiO3M6MzY6Ii9hLzIwMTMtMDYtMDMvMTM3MDIzNjc1OTE1OTc1NjI0LmdpZiI7fQ==','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:46:45','1');");
E_D("replace into `zyads_upadslog` values('4','1','admin','','7','YToyOntzOjM6InVybCI7czoxNzoiaHR0cDovL2Nhb25pbWEucnUiO3M6ODoiaW1hZ2V1cmwiO3M6MzY6Ii9hLzIwMTMtMDYtMDMvMTM3MDIzNTU1NTIxNjQyNTc1LmdpZiI7fQ==','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:47:02','1');");
E_D("replace into `zyads_upadslog` values('5','2','admin','','20','YToyOntzOjM6InVybCI7czoyNToiaHR0cDovL3d3dy5saXl1YW56aGFvLmNvbSI7czo4OiJpbWFnZXVybCI7czozNjoiL2EvMjAxMy0wNi0wMi8xMzcwMTQ1OTk2MTI1MDc5MzQuZ2lmIjt9','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:47:16','1');");
E_D("replace into `zyads_upadslog` values('6','3','admin','','9','YToxOntzOjM6InVybCI7czoyNToiaHR0cDovL3d3dy5saXl1YW56aGFvLmNvbSI7fQ==','YToxOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7fQ==','2013-12-05 22:47:27','1');");
E_D("replace into `zyads_upadslog` values('7','4','admin','','15','YToyOntzOjM6InVybCI7czoxNzoiaHR0cDovL2Nhb25pbWEucnUiO3M6ODoiaW1hZ2V1cmwiO3M6MzY6Ii9hLzIwMTMtMDYtMDIvMTM3MDE0NjUzOTgxNTU2NTQ1LmdpZiI7fQ==','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:47:33','1');");
E_D("replace into `zyads_upadslog` values('8','5','admin','','16','YToyOntzOjM6InVybCI7czoyNToiaHR0cDovL3d3dy5saXl1YW56aGFvLmNvbSI7czo4OiJpbWFnZXVybCI7czozNjoiL2EvMjAxMy0wNi0wMi8xMzcwMTQ2NzMxNjgzOTExMjQuanBnIjt9','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:47:40','1');");
E_D("replace into `zyads_upadslog` values('9','6','admin','','15','YToyOntzOjM6InVybCI7czoxNzoiaHR0cDovL2Nhb25pbWEucnUiO3M6ODoiaW1hZ2V1cmwiO3M6MzY6Ii9hLzIwMTMtMDYtMDMvMTM3MDIzNjI3MDM3NTc3MTc1LmdpZiI7fQ==','YToyOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7czo4OiJpbWFnZXVybCI7Tjt9','2013-12-05 22:47:47','1');");
E_D("replace into `zyads_upadslog` values('10','8','admin','','16','YToxOntzOjU6InpsaW5rIjtzOjE6IjAiO30=','YToxOntzOjU6InpsaW5rIjtzOjE6IjEiO30=','2013-12-05 22:54:45','1');");
E_D("replace into `zyads_upadslog` values('11','8','admin','','16','YToxOntzOjM6InVybCI7czoxNjoiaHR0cDovL2FrMzQ1LmNvbSI7fQ==','YToxOntzOjM6InVybCI7czoyMDoiaHR0cDovL3d3dy5hazM0NS5jb20iO30=','2013-12-05 23:03:37','1');");
E_D("replace into `zyads_upadslog` values('12','5','admin','','16','YToxOntzOjU6InpsaW5rIjtzOjE6IjAiO30=','YToxOntzOjU6InpsaW5rIjtzOjE6IjEiO30=','2013-12-05 23:37:17','1');");
E_D("replace into `zyads_upadslog` values('13','9','admin','','16','YTo1OntzOjM6InVybCI7czoyMToiaHR0cDovL3d3dy5hazM0NS5jb20vIjtzOjg6ImltYWdldXJsIjtzOjM2OiIvYS8yMDEzLTEyLTA2LzEzODYzMjAyMzU4MjE3MDQxMS5qcGciO3M6NToid2lkdGgiO3M6MzoiNDY4IjtzOjY6ImhlaWdodCI7czoyOiI2MCI7czo2OiJhZGluZm8iO3M6MDoiIjt9','YTo1OntzOjM6InVybCI7czoyMToiaHR0cDovL3d3dy5hazM0NS5jb20vIjtzOjg6ImltYWdldXJsIjtzOjM2OiIvYS8yMDEzLTEyLTA2LzEzODYzMjkwNzY1NTIyMjE2OC5naWYiO3M6NToid2lkdGgiO2k6NDY4O3M6NjoiaGVpZ2h0IjtpOjYwO3M6NjoiYWRpbmZvIjtzOjA6IiI7fQ==','2013-12-06 19:24:35','1');");

require("../../inc/footer.php");
?>