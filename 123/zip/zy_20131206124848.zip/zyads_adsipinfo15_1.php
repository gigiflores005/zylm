<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipinfo15`;");
E_C("CREATE TABLE `zyads_adsipinfo15` (
  `ipinfoid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refererid` int(10) unsigned NOT NULL,
  `siteurlid` int(10) unsigned NOT NULL,
  `useragentid` mediumint(8) unsigned NOT NULL,
  `viewtime` int(11) unsigned NOT NULL DEFAULT '0',
  `deduction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `clicks` int(11) unsigned NOT NULL DEFAULT '0',
  `scrollh` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `plugins` varchar(50) DEFAULT NULL,
  `screen` varchar(15) DEFAULT NULL,
  `price` varchar(9) DEFAULT NULL,
  `priceadv` varchar(9) DEFAULT NULL,
  `xx` varchar(50) DEFAULT NULL,
  `yy` varchar(50) DEFAULT NULL,
  `x` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `y` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `n` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `g` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `t` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ipinfoid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipinfo15` values('1','2','2','21','1373844667','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('2','1','1','19','1373851519','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('3','1','1','24','1373853085','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('4','1','1','30','1373857828','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('5','2','2','38','1373861105','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('6','1','1','15','1373869043','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('7','2','2','1','1373869196','0','1','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('8','1','1','28','1373878458','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('9','1','1','14','1373897506','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo15` values('10','2','2','22','1373899684','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");

require("../../inc/footer.php");
?>