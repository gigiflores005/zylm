<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipreferer7`;");
E_C("CREATE TABLE `zyads_adsipreferer7` (
  `referer` varchar(1000) DEFAULT NULL,
  `refererid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`refererid`),
  KEY `referer` (`referer`(500))
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipreferer7` values('','1');");
E_D("replace into `zyads_adsipreferer7` values('http://www.liyuanzhao.com/','2');");
E_D("replace into `zyads_adsipreferer7` values('http://www.liyuanzhao.com/video/search.php?kw=%E4%B8%AD%E5%9B%BD%E5%A5%BD%E5%A3%B0%E9%9F%B3','3');");
E_D("replace into `zyads_adsipreferer7` values('http://www.admin5.net/thread-8445006-1-1.html','4');");
E_D("replace into `zyads_adsipreferer7` values('http://www.x0099.com/xyfjyfl.php?action=left','5');");
E_D("replace into `zyads_adsipreferer7` values('http://www.baoxiaotuan.com/','6');");

require("../../inc/footer.php");
?>