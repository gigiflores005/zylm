<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipinfo20`;");
E_C("CREATE TABLE `zyads_adsipinfo20` (
  `ipinfoid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refererid` int(10) unsigned NOT NULL,
  `siteurlid` int(10) unsigned NOT NULL,
  `useragentid` mediumint(8) unsigned NOT NULL,
  `viewtime` int(11) unsigned NOT NULL DEFAULT '0',
  `deduction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `clicks` int(11) unsigned NOT NULL DEFAULT '0',
  `scrollh` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `plugins` varchar(50) DEFAULT NULL,
  `screen` varchar(15) DEFAULT NULL,
  `price` varchar(9) DEFAULT NULL,
  `priceadv` varchar(9) DEFAULT NULL,
  `xx` varchar(50) DEFAULT NULL,
  `yy` varchar(50) DEFAULT NULL,
  `x` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `y` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `n` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `g` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `t` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ipinfoid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipinfo20` values('1','1','1','33','1374251316','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('2','1','3','27','1374286121','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('3','1','1','21','1374294604','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('4','2','2','21','1374299496','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('5','1','1','9','1374304272','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('6','1','1','10','1374306788','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('7','1','1','1','1374311016','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('8','1','1','31','1374315500','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('9','7','7','31','1374316423','0','1','139','11.5.502.146','1280x768','0.07','0.08','653,853,596,837','87,18,47,1','788','51','4','63','23313');");
E_D("replace into `zyads_adsipinfo20` values('10','1','1','12','1374329731','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('11','1','4','12','1374329732','0','1','707','11.7.700','1366x768','0.07','0.08','547,447,629','10,64,86','636','15','3','102','25650');");
E_D("replace into `zyads_adsipinfo20` values('12','1','1','14','1374329938','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");
E_D("replace into `zyads_adsipinfo20` values('13','1','1','34','1374331227','0','0','0','','','0.005','0.006','','','0','0','0','0','0');");

require("../../inc/footer.php");
?>