<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_adsipreferer4`;");
E_C("CREATE TABLE `zyads_adsipreferer4` (
  `referer` varchar(1000) DEFAULT NULL,
  `refererid` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`refererid`),
  KEY `referer` (`referer`(500))
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=gbk");
E_D("replace into `zyads_adsipreferer4` values('','1');");
E_D("replace into `zyads_adsipreferer4` values('http://bbs.admin5.com/thread-12188752-1-1.html','2');");
E_D("replace into `zyads_adsipreferer4` values('http://www.liyuanzhao.com/','3');");
E_D("replace into `zyads_adsipreferer4` values('http://www.admin5.net/forum.php?mod=viewthread&tid=12188752&extra=page%3D5%26filter%3Dsortid%26sortid%3D310%26sortid%3D310','4');");
E_D("replace into `zyads_adsipreferer4` values('http://www.admin5.net/thread-8445006-1-1.html','5');");
E_D("replace into `zyads_adsipreferer4` values('http://www.admin5.net/thread-12188752-1-10.html','6');");
E_D("replace into `zyads_adsipreferer4` values('http://www.admin5.net/forum.php?mod=viewthread&tid=13148935&extra=page%3D1%26filter%3Dsortid%26sortid%3D310%26sortid%3D310','7');");

require("../../inc/footer.php");
?>