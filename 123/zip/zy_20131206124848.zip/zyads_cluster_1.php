<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `zyads_cluster`;");
E_C("CREATE TABLE `zyads_cluster` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `clusterid` tinyint(3) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>